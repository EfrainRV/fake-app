'use client'

import { useRouter } from "next/navigation"

export const PdfButton = () => {
  const router = useRouter()

  const handleRedirect = async () =>{
    router.push("/document")
  }

  return (
    <button 
      className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      onClick={handleRedirect}
    >
      Generar PDF
    </button>
  )
}
