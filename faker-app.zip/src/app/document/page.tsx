'use client'

import { Document } from "@/components/pdf/Document"
import { useEffect, useState } from "react"

export default function Template() {
  const [users, setUsers] = useState([])
  
  const getUsers = async () => {
    const response = await fetch("/api/users")
    const { users } = await response.json()
    setUsers(users)
  }

  useEffect(() => {
    getUsers()
  }, [])

  return (
    <Document users={users}/>
  )
}

